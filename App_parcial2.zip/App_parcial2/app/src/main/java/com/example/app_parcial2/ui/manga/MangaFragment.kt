package com.example.app_parcial2.ui.manga

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.app_parcial2.R

class MangaFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_manga, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Cargar la imagen y establecer el texto para "One Piece"
        cargarImagen(R.id.piece_imagen, R.drawable.piece_imagen)
        establecerTexto(
            R.id.text_piece_description,
            getString(R.string.one_piece_description)
        )

        // imagen y establecer el texto para "Kaguya-sama"
        cargarImagen(R.id.kaguya_imagen, R.drawable.kaguya_imagen)
        establecerTexto(
            R.id.text_kaguya_description,
            getString(R.string.kaguya_description)
        )

        // imagen y establecer el texto para "Tokyo Ghoul"
        cargarImagen(R.id.tokyo_imagen, R.drawable.tokyo_imagen)
        establecerTexto(
            R.id.text_tokyo_description,
            getString(R.string.tokyo_ghoul_description)
        )
    }

    private fun cargarImagen(idImageView: Int, idDrawable: Int) {
        val imageView: ImageView = view?.findViewById(idImageView) ?: return
        imageView.setImageResource(idDrawable)
    }

    private fun establecerTexto(idTextView: Int, texto: String) {
        val textView: TextView = view?.findViewById(idTextView) ?: return
        textView.text = texto
    }
}