package com.example.app_parcial2.ui.manga

import androidx.lifecycle.ViewModel

class MangaViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}