package com.example.app_parcial2.ui.personajes

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.app_parcial2.R
import android.widget.ImageView
import android.widget.TextView

class PersonajesFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_personajes, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Cargar imágenes y establecer textos para cada sección
        cargarImagenTexto(R.id.image_section1, R.drawable.imagen1, R.string.biography_section1)
        cargarImagenTexto(R.id.image_section2, R.drawable.imagen2, R.string.biography_section2)
        cargarImagenTexto(R.id.image_section3, R.drawable.imagen3, R.string.biography_section1)
        cargarImagenTexto(R.id.image_section4, R.drawable.imagen4, R.string.biography_section2)
        cargarImagenTexto(R.id.image_section5, R.drawable.imagen5, R.string.biography_section2)
    }

    private fun cargarImagenTexto(idImagen: Int, idDrawable: Int, idTexto: Int) {
        view?.findViewById<ImageView>(idImagen)?.setImageResource(idDrawable)
        view?.findViewById<TextView>(idTexto)?.text = getString(idTexto)
    }
}