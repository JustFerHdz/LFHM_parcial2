package com.example.app_parcial2.ui.novela

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.fragment.app.Fragment
import com.example.app_parcial2.R
import com.google.android.material.snackbar.Snackbar

class NovelaFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_novela, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Configurar clics en las imágenes
        view.findViewById<ImageView>(R.id.image1).setOnClickListener {
            mostrarMensaje(it)
        }
        view.findViewById<ImageView>(R.id.image2).setOnClickListener {
            mostrarMensaje(it)
        }
        view.findViewById<ImageView>(R.id.image3).setOnClickListener {
            mostrarMensaje(it)
        }
        view.findViewById<ImageView>(R.id.image4).setOnClickListener {
            mostrarMensaje(it)
        }
    }

    private fun mostrarMensaje(view: View) {
        val tag = view.tag.toString()
        Snackbar.make(view, tag, Snackbar.LENGTH_LONG).show()
    }
}